#pragma once
//------------------------------------------------------------------------------
// Copyright (c) 2021 Cohda Wireless Pty Ltd
//-----------------------------------------------------------------------------

#ifdef __cplusplus
extern "C"
{
#endif
  // Cust_App_RLW.DebugLevel
  extern int RLW_Cust_App_RLW_DebugLevel;

#ifdef __cplusplus
}
#endif
