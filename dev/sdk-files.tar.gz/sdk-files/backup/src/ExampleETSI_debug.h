#pragma once
//------------------------------------------------------------------------------
// Copyright (c) 2021 Cohda Wireless Pty Ltd
//-----------------------------------------------------------------------------

#ifdef __cplusplus
extern "C"
{
#endif
  // ExampleETSI.DebugLevel
  extern int ExampleETSI_ExampleETSI_DebugLevel;
  // ExampleETSI.CANThr.DebugLevel
  extern int ExampleETSI_ExampleETSI_CANThr_DebugLevel;
  // ExampleETSI.CANVState.DebugLevel
  extern int ExampleETSI_ExampleETSI_CANVState_DebugLevel;
  // ExampleETSI.ITSCtrl.DebugLevel
  extern int ExampleETSI_ExampleETSI_ITSCtrl_DebugLevel;
  // ExampleETSI.ITSRx.DebugLevel
  extern int ExampleETSI_ExampleETSI_ITSRx_DebugLevel;
  // ExampleETSI.ITSTx.DebugLevel
  extern int ExampleETSI_ExampleETSI_ITSTx_DebugLevel;
  // ExampleETSI.Main.DebugLevel
  extern int ExampleETSI_ExampleETSI_Main_DebugLevel;
  // ExampleETSI.PosExt.DebugLevel
  extern int ExampleETSI_ExampleETSI_PosExt_DebugLevel;
  // ExampleETSI.Raw.DebugLevel
  extern int ExampleETSI_ExampleETSI_Raw_DebugLevel;

#ifdef __cplusplus
}
#endif
